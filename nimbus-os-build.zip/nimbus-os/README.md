# Nimbus OS (working name)

Debian 13 "trixie" + Xfce, built with Debian's `live-build`.

- Wallpaper: your 3D clouds (`/usr/share/backgrounds/nimbus/wallpaper.png`)
- Top bar + floating bottom dock (Plank) laid out like your Explorer mockup
- Firefox ESR preinstalled, your Firefox logo used for the dock/menu/window icon
- Apps: GNOME Calculator, GNOME Calendar, Thunar files, Mousepad, Terminal, Evince PDF, Ristretto images, Archive manager
- Boot: Plymouth splash (floating cloud + progress bar), custom boot-menu splash
- Calamares installer included, so the ISO can be installed to disk

## Build (needs a Debian/Ubuntu machine or VM with internet, ~15 GB free, ~20-40 min)

    sudo ./build.sh

Output: `nimbus-os-amd64.hybrid.iso`. Test in VirtualBox/QEMU first, then write to USB with Balena Etcher or `dd`.
Live login is automatic (user `nimbus`, password `live`).

## Where things are
- `config/package-lists/nimbus.list.chroot`   software list
- `config/includes.chroot_after_packages/`   files copied into the OS (themes, panel, dock, boot splash)
- `config/hooks/live/0100-nimbus.hook.chroot`   final setup steps
- `make_assets.py`   regenerates icons/splash from your source images
- `branding/`   boot-screen preview and boot-menu images

## Known limits
- XFCE has no global File/Edit/View/Help menu; the top bar shows "Explorer" (opens the app menu), tray and clock.
- Wallpaper source is 1280x720, upscaled to 1920x1080. A higher-res export will look sharper.
- Calamares installer still carries Debian's branding.

## Build without a Debian machine (GitHub Actions)
1. Create a new GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the repo's **Actions** tab, choose **Build Nimbus OS ISO**, click **Run workflow**.
3. After ~30-60 min, download `nimbus-os-iso` from the finished run's Artifacts section and unzip it for the .iso.
