import os, math
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from scipy import ndimage

U="/mnt/user-data/uploads/"
R="config/includes.chroot_after_packages"
def mk(p): os.makedirs(p, exist_ok=True); return p
FONT="/usr/share/fonts/truetype/google-fonts/Poppins-%s.ttf"

# ---------- wallpaper ----------
wp = Image.open(U+"Untitled_design_4_.png").convert("RGB")
mk(f"{R}/usr/share/backgrounds/nimbus")
wp.resize((1920,1080), Image.LANCZOS).save(f"{R}/usr/share/backgrounds/nimbus/wallpaper.png")
wp.save(f"{R}/usr/share/backgrounds/nimbus/wallpaper-1280x720.png")

# ---------- cloud cutout (middle cloud) ----------
a = np.array(wp).astype(float)
nonwhite = a.min(axis=2) < 245
lab, n = ndimage.label(nonwhite)
# component containing a pixel in the middle cloud
cid = lab[200, 900]
mask = (lab == cid)
mask = ndimage.binary_dilation(mask, iterations=1)
ys, xs = np.where(mask)
box = (xs.min()-2, ys.min()-2, xs.max()+3, ys.max()+3)
alpha = np.clip((255 - a.min(axis=2)) / 40.0, 0, 1) * mask
rgba = np.dstack([a, alpha*255]).astype(np.uint8)
cloud = Image.fromarray(rgba, "RGBA").crop(box)

# ---------- Firefox icons (user's logo) ----------
ff = Image.open(U+"1793325265324_image.png").convert("RGBA")
s = max(ff.size); sq = Image.new("RGBA", (s,s), (0,0,0,0)); sq.paste(ff, ((s-ff.width)//2,(s-ff.height)//2))
def icons(img, name, sizes=(16,22,24,32,48,64,128,256)):
    for z in sizes:
        d = mk(f"{R}/usr/share/icons/hicolor/{z}x{z}/apps")
        img.resize((z,z), Image.LANCZOS).save(f"{d}/{name}.png")
    mk(f"{R}/usr/share/pixmaps"); img.resize((128,128), Image.LANCZOS).save(f"{R}/usr/share/pixmaps/{name}.png")
icons(sq, "nimbus-firefox")
# Firefox's own window/icon files
d = mk("branding")
for z in (16,32,48,64,128):
    sq.resize((z,z), Image.LANCZOS).save(f"branding/firefox-default{z}.png")

# ---------- launcher dot ----------
def dot(S=512):
    im = Image.new("RGBA",(S,S),(0,0,0,0)); px = im.load()
    c = S/2; r = S*0.42
    for y in range(S):
        for x in range(S):
            dx,dy = x-c,y-c; dist = math.hypot(dx,dy)
            if dist <= r:
                t = (y/S)*0.5 + (x/S)*0.2
                col = (int(0x6b-0x18*t*2), int(0x88-0x20*t*2), 255)
                px[x,y]=(*col,255)
    return im.filter(ImageFilter.GaussianBlur(0.6))
dotimg = dot()
icons(dotimg, "nimbus-launcher")

# ---------- terminal / code-window icon ----------
def term(S=512):
    sc=4; W=S*sc; im=Image.new("RGBA",(W,W),(0,0,0,0)); d=ImageDraw.Draw(im)
    col=(40,40,48,255); lw=int(W*0.035)
    d.rounded_rectangle((W*0.14,W*0.22,W*0.86,W*0.78), radius=W*0.04, outline=col, width=lw)
    d.line((W*0.14,W*0.33,W*0.86,W*0.33), fill=col, width=int(lw*0.8))
    for i in range(3):
        cx=W*(0.2+i*0.045); d.ellipse((cx-W*0.009,W*0.275-W*0.009,cx+W*0.009,W*0.275+W*0.009), fill=col)
    # < >
    w=int(lw*1.1)
    d.line([(W*0.43,W*0.47),(W*0.34,W*0.555),(W*0.43,W*0.64)], fill=col, width=w, joint="curve")
    d.line([(W*0.57,W*0.47),(W*0.66,W*0.555),(W*0.57,W*0.64)], fill=col, width=w, joint="curve")
    return im.resize((S,S), Image.LANCZOS)
icons(term(), "nimbus-terminal")

# ---------- gear ----------
def gear(S=512):
    sc=4; W=S*sc; im=Image.new("RGBA",(W,W),(0,0,0,0)); d=ImageDraw.Draw(im)
    c=W/2; ro=W*0.40; ri=W*0.31; teeth=8; pts=[]
    for i in range(teeth):
        base=2*math.pi*i/teeth
        for ang,rad in ((-0.17,ri),(-0.11,ro),(0.11,ro),(0.17,ri)):
            a_=base+ang*1.6; pts.append((c+rad*math.cos(a_), c+rad*math.sin(a_)))
    d.polygon(pts, fill=(78,78,84,255))
    d.ellipse((c-ri*1.02,c-ri*1.02,c+ri*1.02,c+ri*1.02), fill=(78,78,84,255))
    hr=W*0.115; d.ellipse((c-hr,c-hr,c+hr,c+hr), fill=(0,0,0,0))
    return im.resize((S,S), Image.LANCZOS)
icons(gear(), "nimbus-settings")

# ---------- Plymouth theme ----------
P = mk(f"{R}/usr/share/plymouth/themes/nimbus")
ch = 170; cl = cloud.resize((int(cloud.width*ch/cloud.height), ch), Image.LANCZOS); cl.save(f"{P}/cloud.png")
def wordmark(txt, size, col):
    f = ImageFont.truetype(FONT%"Medium", size)
    tmp = Image.new("RGBA",(10,10)); w = int(ImageDraw.Draw(tmp).textlength(txt, font=f))+4
    im = Image.new("RGBA",(w,int(size*1.6)),(0,0,0,0)); ImageDraw.Draw(im).text((2,2), txt, font=f, fill=col); return im
wordmark("Nimbus OS", 34, (90,106,168,255)).save(f"{P}/wordmark.png")
def bar(col, w=360, h=6):
    sc=4; im=Image.new("RGBA",(w*sc,h*sc),(0,0,0,0)); ImageDraw.Draw(im).rounded_rectangle((0,0,w*sc-1,h*sc-1), radius=h*sc/2, fill=col)
    return im.resize((w,h), Image.LANCZOS)
bar((227,232,250,255)).save(f"{P}/bar-bg.png"); bar((91,124,255,255)).save(f"{P}/bar-fill.png")

# ---------- bootloader splash (dark gradient so menu text stays readable) ----------
def gradient(W,H,top,bot):
    g=np.zeros((H,W,3),np.uint8)
    for i in range(3): g[:,:,i]=np.linspace(top[i],bot[i],H)[:,None]
    return Image.fromarray(g,"RGB")
sp = gradient(640,480,(18,24,58),(46,62,150)).convert("RGBA")
c2 = cloud.resize((int(cloud.width*110/cloud.height),110), Image.LANCZOS)
sp.alpha_composite(c2,(640-c2.width-30,30))
ImageDraw.Draw(sp).text((30,34),"Nimbus OS",font=ImageFont.truetype(FONT%"Medium",26),fill=(255,255,255,255))
sp.convert("RGB").save("branding/splash-640x480.png")
gradient(1920,1080,(18,24,58),(46,62,150)).save("branding/grub-background-1920x1080.png")

# ---------- LightDM / misc ----------
# (greeter reuses the wallpaper)

# ---------- previews ----------
prev = Image.new("RGB",(1920,1080),(255,255,255)); prev.paste(cl,((1920-cl.width)//2,330),cl)
w = wordmark("Nimbus OS",44,(90,106,168,255)); prev.paste(w,((1920-w.width)//2,590),w)
bg_=bar((227,232,250,255),540,8); fg_=bar((91,124,255,255),210,8)
prev.paste(bg_,((1920-540)//2,720),bg_); prev.paste(fg_,((1920-540)//2,720),fg_)
prev.save("branding/boot-screen-preview.png")
print("assets done", cl.size)
