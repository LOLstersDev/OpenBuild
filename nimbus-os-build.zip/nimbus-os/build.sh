#!/bin/bash
# Nimbus OS builder — run on Debian/Ubuntu as root:  sudo ./build.sh
set -euo pipefail
cd "$(dirname "$0")"
[ "$(id -u)" = 0 ] || { echo "Run as root: sudo ./build.sh"; exit 1; }
apt-get update && apt-get install -y live-build librsvg2-bin

lb clean --purge 2>/dev/null || true

lb config \
  --distribution trixie \
  --architectures amd64 \
  --archive-areas "main contrib non-free non-free-firmware" \
  --debian-installer none \
  --binary-image iso-hybrid \
  --bootloaders "syslinux,grub-efi" \
  --memtest none \
  --firmware-chroot true \
  --iso-application "Nimbus OS" \
  --iso-volume "NIMBUS_1" \
  --image-name "nimbus-os" \
  --bootappend-live "boot=live components quiet splash username=nimbus hostname=nimbus"

# Boot-menu artwork: copy live-build's default bootloader files, swap in ours (best effort)
mkdir -p config/bootloaders
cp -a /usr/share/live/build/bootloaders/. config/bootloaders/
find config/bootloaders -name 'splash.svg' -delete
find config/bootloaders -name 'splash.png' -exec cp branding/splash-640x480.png {} \;
for d in config/bootloaders/syslinux* config/bootloaders/isolinux; do
  [ -d "$d" ] && cp branding/splash-640x480.png "$d/splash.png"
done

lb build 2>&1 | tee build.log
echo; ls -lh ./*.iso
